/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cajero;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;


/**
 *
 * @author ferna
 */
public class Conexion {
    //Se declarara un metodo que permita la conexión con la base de datos
    public Connection getConection (){
        Connection con = null;
        String base = "cajero"; //Se establece el nombre de la base de datos
        String url = "jdbc:mysql://localhost:3306/" + base; // Se estable la dirección, el puerto y el nombre de la base de datos
        String user = "root"; // Credencial de usuario de acceso a MYSQL  
        String password = ""; //Contraseña del usuario
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(url, user, password);
        } catch (Exception e){
            System.err.println(e);
        }
        
        return con;
    }
}
